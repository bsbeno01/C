﻿/*
 * Grading ID:B2106
 * Class: CIS 199
 * Section:75
 * Program 4
 * Due Date: December 5th, 2017
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class LibraryBook
    {
        private string _title, _author, _publisher, _callnumber; //setting up private string variables to be used in read onlys

        private bool _checkedout; //setting up private boolean variable to be used in methods
       
        private int _copyrightyear;
        //read-only property that retrieves  the title of the book
        //precondition: _title holds no value
        //Postcondition: _title returns a value from the main
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }
        //read-only property that retrieves the author of the book
        //precondition: _author holds no value
        //Postcondition: _author returns a value from the main
        public string Author
        {
            get { return _author; }
            set { _author = value; }
        }
        //read-only property that retrieves the publisher of the book
        //precondition: _publisher holds no value
        //Postcondition: _publisher returns a value from the main
        public string Publisher
        {
            get { return _publisher; }
            set { _publisher = value; }
        }
        //read-only property that retrieves the copyright year
        //precondition: _Copyrightyear holds no value
        //Postcondition: _title returns a value from the main
        public int CopyrightYear
        {

            get { return _copyrightyear; }

            set
            {
                if (value >= 0)
                    _copyrightyear = value;
                else
                    _copyrightyear = 2017;
            }
        }
        //readonly property that retrieves the call number
        //precondition: _callnumber holds no value
        //Postcondition: _callnumber returns a value from the main
        public string CallNumber
        {
            get { return _callnumber; }
            set { _callnumber = value; }
        }
        //five-parameter contructor
        public LibraryBook(string title, string author, string publisher, int copyrightyear, string callnumber)
        {
            Title = title;
            Author = author;
            Publisher = publisher;
            CopyrightYear = copyrightyear;
            CallNumber = callnumber;

        }
        //Pre-conditions: prior to implementation _checkedout will hold a False values
        //Post-Conditions: _checked out is changed to a true value
        public void CheckOut()
        {
            _checkedout = true;
        }
        //Pre-conditions: _checkedout should hold a false value, unless Checkout method utilized prior
        //if used than _checkedout should hold a true value
        //Post-conditions: _checkedout holds a false value
        public void ReturnToShelf()
        {
            _checkedout = false;
        }
        //Preconditions: no specific boolean value is returned 
        //Postconditions: IsCheckedOut now returns whatever value is held in _checkedout
        public bool IsCheckedOut()
        {
            return _checkedout;
        }
        //overriding string method to pass values in properties as strings.
        public override string ToString()
        {
            return $"Title: {Title}{Environment.NewLine}" +
                $"Author: {Author}{Environment.NewLine}" +
                $"Publisher: {Publisher}{Environment.NewLine}" +
                $"Copyright Year:{CopyrightYear}{Environment.NewLine}" +
                $"Call Number:{CallNumber}{Environment.NewLine}"+
                //PreConditions:There is no string to hold a boolean value to represent whether the book is checked out
                //PostConditions: IsCheckedOut method is called and interpolated. 
                 $"Is the book checked out?: {IsCheckedOut()}";

        }


    }
}
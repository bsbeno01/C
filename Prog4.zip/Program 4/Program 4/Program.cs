﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    class Program
    {
        static void Main(string[] args)
        {

            //Creating derived class objects
            LibraryBook book1 = new LibraryBook("The Tin Drum", "Gunter Grass", "Hermann Luchterhand Verlag", 1959, "3618781");


            LibraryBook book2 = new LibraryBook("Ulysses", "James Joyce", "Sylvia Beach", 1922, "54106672");

            LibraryBook book3 = new LibraryBook("The Alchemist", "Paulo Coelo", "HarperTorch", 1988, "26857452");

            LibraryBook book4 = new LibraryBook("Grapes of Wrath", "John Steinbeck", "The Viking Press", 1939, "289946");

            LibraryBook book5 = new LibraryBook("Letters to a Young Contrarian", "Christopher Hitchens", "Basic Books", 2001, "60683604");

            LibraryBook[] books = new LibraryBook[5];

            //initialize arrays with books as derived type

            books[0] = book1;
            books[1] = book2;
            books[2] = book3;
            books[3] = book4;
            books[4] = book5;

            //PreConditions: Console displays nothing
            //PostConditions Console displays information held in array
            PrintBooks(books);

            //Preconditions: book1 _checkedout is false
            //Postconditions: book1 _checkedout is true
            book1.CheckOut();

            //Preconditions: book2 _checkedout is false
            //Postconditions: book2 _checkedout is true
            book2.CheckOut();


            //Preconditions: Copyright year holds the value in class objects
            //Postconditions:Copyright year value is altered to -1
            book1.CopyrightYear = -1;


            //preconditions:the updated values are not available on the console
            //postconditions: the updated values are now avaiable on the console
            PrintBooks(books);

            //Preconditions:book is not on the shelf
            //Postconditions: book is returned to shelf value is returned to false value
            book1.ReturnToShelf();

            //Preconditions:book is not on the shelf
            //Postconditions: book is returned to shelf value is returned to false value
            book2.ReturnToShelf();

            //Preconditions: call number  holds the value in class objects
            //Postconditions:call number value is altered to 12345
            book1.CallNumber = "12345";
            PrintBooks(books);
        }
        //Preconditions: An array is passed to PrintBooks method
        //PostConditions: This array is then looped, and Displays in the console  the derived information passed from the array, derived from class objects
        private static void PrintBooks(params LibraryBook[] books)
        {
            
            foreach (LibraryBook book in books)
            {
                
                Console.WriteLine(book);
                Console.WriteLine();



            }
        }
    }
}


﻿//Grading ID: B2106
//Program 2
//October 22, 2017
//CIS 199-75
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void datesBT_Click(object sender, EventArgs e)
        {

            string nameLS = lastTB.Text; // setting up the string variable to equal what is entered into the lastTB textbox

            char firstLT = char.ToUpper(nameLS[0]); //variable that sets firstLT to the capitalized first letter of nameLS variable

            string regIntro = "Your registration begins ";// Variabl representing begining string inserted into every comment
            string seniorDate = "November 3"; //Variable representing the Senior Registration Date
            string jrDate = "November 6"; //variable representing the Junior registration date
            string sophDateA = "November 7";//Variable reprenting the earliest registration begining date for Sophmores
            string sophDateB = "November 8";//Variable representing the latest registration begining date for Sophmores
            string freshDateA = "November 9";//Variable representing the earliest registration begining date for Freshman
            string freshDateB = "November 10";//Variable representing the latest registration begining date for Freshman

            string firstTime = "11:30 A.M."; // variable representing string 11:30 A.M.
            string secondTime = "2:00 P.M."; //Variable representing string 2:00 P.M.
            string thirdTime = "4:00 P.M."; //Variable representing string 4:00 P.M.
            string fourthTime = "8:30 A.M."; // Variable representing string 8:30 A.M.
            string fifthTime = "10:00 A.M."; //Variable representing string 10:00 A.M.
            string timeT;
            string dateT;

            if (senRDB.Checked || junRDB.Checked)
            {
                if (firstLT <= 'D')
                    timeT = fifthTime;
                else if (firstLT <= 'I')
                    timeT = firstTime;
                else if (firstLT <= 'O')
                    timeT = secondTime;
                else if (firstLT <= 'S')
                    timeT = thirdTime;
                else
                    timeT = fourthTime;
                if (senRDB.Checked)

                    dateT = seniorDate;

                else
                    dateT = jrDate;
                MessageBox.Show($"{regIntro} at {dateT} {timeT}");
                showDateLB.Text = ($"{dateT}");
                showTimeLB.Text = ($"{timeT}");

            }
            else
            {
                if (firstLT <= 'B')

                    timeT = firstTime;

                else if (firstLT <= 'D')

                    timeT = secondTime;

                else if (firstLT <= 'F')

                    timeT = thirdTime;

                else if (firstLT <= 'I')

                    timeT = fourthTime;

                else if (firstLT <= 'L')

                    timeT = fifthTime;

                else if (firstLT <= 'O')

                    timeT = firstTime;

                else if (firstLT <= 'Q')

                    timeT = secondTime;

                else if (firstLT <= 'S')

                    timeT = thirdTime;

                else if (firstLT <= 'V')

                    timeT = fourthTime;

                else
                    timeT = fifthTime;

                {
                    if (sophRDB.Checked && (firstLT <= 'F' || firstLT >= 'T'))
                    {
                        dateT = sophDateA;
                    }
                    else
                    if (sophRDB.Checked && (firstLT >= 'G' || firstLT <= 'S'))
                        dateT = sophDateB;

                    else
                    if (freshRDB.Checked && (firstLT <= 'B' || firstLT >= 'T'))
                    { dateT = freshDateA; }
                    else
                    {
                        dateT = freshDateB;
                    }
                    MessageBox.Show($"{regIntro} at {dateT} {timeT}");
                    showDateLB.Text = ($"{dateT}");
                    showTimeLB.Text = ($"{timeT}");
                }
            }
        }
    }
}

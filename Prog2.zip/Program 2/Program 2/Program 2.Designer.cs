﻿namespace Program_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lastLB = new System.Windows.Forms.Label();
            this.lastTB = new System.Windows.Forms.TextBox();
            this.freshRDB = new System.Windows.Forms.RadioButton();
            this.sophRDB = new System.Windows.Forms.RadioButton();
            this.junRDB = new System.Windows.Forms.RadioButton();
            this.datesBT = new System.Windows.Forms.Button();
            this.senRDB = new System.Windows.Forms.RadioButton();
            this.standingGPB = new System.Windows.Forms.GroupBox();
            this.dateLBL = new System.Windows.Forms.Label();
            this.timeLBL = new System.Windows.Forms.Label();
            this.showDateLB = new System.Windows.Forms.Label();
            this.showTimeLB = new System.Windows.Forms.Label();
            this.standingGPB.SuspendLayout();
            this.SuspendLayout();
            // 
            // lastLB
            // 
            this.lastLB.AutoSize = true;
            this.lastLB.Location = new System.Drawing.Point(0, 12);
            this.lastLB.Name = "lastLB";
            this.lastLB.Size = new System.Drawing.Size(159, 32);
            this.lastLB.TabIndex = 0;
            this.lastLB.Text = "Last Name:";
            // 
            // lastTB
            // 
            this.lastTB.Location = new System.Drawing.Point(165, 12);
            this.lastTB.Name = "lastTB";
            this.lastTB.Size = new System.Drawing.Size(100, 38);
            this.lastTB.TabIndex = 1;
            // 
            // freshRDB
            // 
            this.freshRDB.AutoSize = true;
            this.freshRDB.Location = new System.Drawing.Point(248, 78);
            this.freshRDB.Name = "freshRDB";
            this.freshRDB.Size = new System.Drawing.Size(179, 36);
            this.freshRDB.TabIndex = 2;
            this.freshRDB.TabStop = true;
            this.freshRDB.Text = "Freshman";
            this.freshRDB.UseVisualStyleBackColor = true;
            // 
            // sophRDB
            // 
            this.sophRDB.AutoSize = true;
            this.sophRDB.Location = new System.Drawing.Point(248, 139);
            this.sophRDB.Name = "sophRDB";
            this.sophRDB.Size = new System.Drawing.Size(183, 36);
            this.sophRDB.TabIndex = 3;
            this.sophRDB.TabStop = true;
            this.sophRDB.Text = "Sophmore";
            this.sophRDB.UseVisualStyleBackColor = true;
            // 
            // junRDB
            // 
            this.junRDB.AutoSize = true;
            this.junRDB.Location = new System.Drawing.Point(248, 204);
            this.junRDB.Name = "junRDB";
            this.junRDB.Size = new System.Drawing.Size(130, 36);
            this.junRDB.TabIndex = 4;
            this.junRDB.TabStop = true;
            this.junRDB.Text = "Junior";
            this.junRDB.UseVisualStyleBackColor = true;
            // 
            // datesBT
            // 
            this.datesBT.Location = new System.Drawing.Point(143, 654);
            this.datesBT.Name = "datesBT";
            this.datesBT.Size = new System.Drawing.Size(568, 125);
            this.datesBT.TabIndex = 5;
            this.datesBT.Text = "Show Registration Dates";
            this.datesBT.UseVisualStyleBackColor = true;
            this.datesBT.Click += new System.EventHandler(this.datesBT_Click);
            // 
            // senRDB
            // 
            this.senRDB.AutoSize = true;
            this.senRDB.Location = new System.Drawing.Point(248, 283);
            this.senRDB.Name = "senRDB";
            this.senRDB.Size = new System.Drawing.Size(135, 36);
            this.senRDB.TabIndex = 6;
            this.senRDB.TabStop = true;
            this.senRDB.Text = "Senior";
            this.senRDB.UseVisualStyleBackColor = true;
            // 
            // standingGPB
            // 
            this.standingGPB.Controls.Add(this.freshRDB);
            this.standingGPB.Controls.Add(this.senRDB);
            this.standingGPB.Controls.Add(this.sophRDB);
            this.standingGPB.Controls.Add(this.junRDB);
            this.standingGPB.Location = new System.Drawing.Point(143, 119);
            this.standingGPB.Name = "standingGPB";
            this.standingGPB.Size = new System.Drawing.Size(554, 371);
            this.standingGPB.TabIndex = 7;
            this.standingGPB.TabStop = false;
            this.standingGPB.Text = "Class Standing:";
            // 
            // dateLBL
            // 
            this.dateLBL.AutoSize = true;
            this.dateLBL.Location = new System.Drawing.Point(194, 517);
            this.dateLBL.Name = "dateLBL";
            this.dateLBL.Size = new System.Drawing.Size(83, 32);
            this.dateLBL.TabIndex = 8;
            this.dateLBL.Text = "Date:";
            // 
            // timeLBL
            // 
            this.timeLBL.AutoSize = true;
            this.timeLBL.Location = new System.Drawing.Point(525, 507);
            this.timeLBL.Name = "timeLBL";
            this.timeLBL.Size = new System.Drawing.Size(86, 32);
            this.timeLBL.TabIndex = 9;
            this.timeLBL.Text = "Time:";
            // 
            // showDateLB
            // 
            this.showDateLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.showDateLB.Location = new System.Drawing.Point(113, 574);
            this.showDateLB.Name = "showDateLB";
            this.showDateLB.Size = new System.Drawing.Size(246, 54);
            this.showDateLB.TabIndex = 10;
            // 
            // showTimeLB
            // 
            this.showTimeLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.showTimeLB.Location = new System.Drawing.Point(486, 574);
            this.showTimeLB.Name = "showTimeLB";
            this.showTimeLB.Size = new System.Drawing.Size(125, 54);
            this.showTimeLB.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 791);
            this.Controls.Add(this.showTimeLB);
            this.Controls.Add(this.showDateLB);
            this.Controls.Add(this.timeLBL);
            this.Controls.Add(this.dateLBL);
            this.Controls.Add(this.standingGPB);
            this.Controls.Add(this.datesBT);
            this.Controls.Add(this.lastTB);
            this.Controls.Add(this.lastLB);
            this.Name = "Form1";
            this.Text = "Program 2";
            this.standingGPB.ResumeLayout(false);
            this.standingGPB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lastLB;
        private System.Windows.Forms.TextBox lastTB;
        private System.Windows.Forms.RadioButton freshRDB;
        private System.Windows.Forms.RadioButton sophRDB;
        private System.Windows.Forms.RadioButton junRDB;
        private System.Windows.Forms.Button datesBT;
        private System.Windows.Forms.RadioButton senRDB;
        private System.Windows.Forms.GroupBox standingGPB;
        private System.Windows.Forms.Label dateLBL;
        private System.Windows.Forms.Label timeLBL;
        private System.Windows.Forms.Label showDateLB;
        private System.Windows.Forms.Label showTimeLB;
    }
}


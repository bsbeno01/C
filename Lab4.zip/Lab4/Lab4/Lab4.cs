﻿//Lab4
//Due:  2/19/2017
//CIS 199-02
//By: B2707

//This program allows user to input a Test Score and a GPA for a student.
//The criteria for admissions is a test score of 80, or a test score of 60 and a High School GPA of 3.0
//Based on this criteria students are either rejected, or admitted
//This will result in a message that notifies whether the student has been accepted or rejected
//The program will also keep running totals of those students accepted, and those students rejected



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Lab4 : Form
    {
        private const float GPA = 3.0f; //setting constant GPA compare value to 3.0
        private const int ADMINHIGH = 80;//setting constant High test score value to 80
        private const int ADMINLOW = 60;//setting constant Low test score value to 60
        private const float TBVALUE = 0f;//setting textbox values to a  const to 0
        private  int ADMTOT = 0;//setting admission total to 0
        private  int REJTOT = 0;//setting rejection total to 0

        public Lab4()
        {

            InitializeComponent();
        }

        private void testTB_KeyPress(object sender, KeyPressEventArgs e)//setting up a key press event to limit user to numbers only
        {
            // utilizing if statement that limit user to only one decimal point
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void gpaTB_KeyPress(object sender, KeyPressEventArgs e)// setting up a keypress event to limit user to numbers only as well as 1 decimal only
        {
            //utilizing if statement to limit user to only numerical inputs and decimal inputs       
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // utilizing if statement that limit user to only one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void admSTATBT_Click(object sender, EventArgs e)
        {
            //declare Variables
            int testScore; //testScore variable deals with test score inputs
            float studentGPA; //studentGPA variable deals with GPA inputs


            if (int.TryParse(testTB.Text, out testScore))//ensure inputs within the testTB TextBox are limited to integers
            {
                if (float.TryParse(gpaTB.Text, out studentGPA))//ensure inputs withing the gpaTB textbox are limited to float
                {
                    if (testScore >= ADMINHIGH)//ensure inputs are greater than or equal to ADMINHIGH constant (score of 80)
                    {
                        MessageBox.Show("Student Admitted");//display student admitted
                        ADMTOT += 1; //count student admissions
                        acceptCountLB.Text = (ADMTOT.ToString("N0")); //display running total in acceptCountLB label
                    }
                    else if (testScore >= ADMINLOW && studentGPA >= GPA) //ensure test score is greater than or equal to ADMINLOW (60) for testScore
                                                                         //ensure GPA is greater than or equal GPA (3.0) value
                    {
                        MessageBox.Show("Student Admitted");//display student admitted
                        ADMTOT += 1;//count student admissions
                        acceptCountLB.Text = (ADMTOT.ToString("n0"));//display running total
                    }
                    else//student requirements not met thus false, false scenario includes rejection
                    {
                        MessageBox.Show("Student Rejected");//display student is rejected
                        REJTOT += 1;//count student's rejection
                        rejCountLB.Text = (REJTOT.ToString("n0"));//keep running total of student rejection
                    }
                }
                else//if gpaTB does not include correct number format inputs
                {
                    MessageBox.Show("Please enter the correct GPA"); 
                }
            }
            else//if testTB does not include the correct number format inputs
            {
                MessageBox.Show("Please enter the correct Test Score");
            }
        }

        private void Lab4_Load(object sender, EventArgs e) //creating load event
        {
            acceptCountLB.Text = ADMTOT.ToString("n0");//setting acceptCountLB label to 0 value
            rejCountLB.Text = REJTOT.ToString("n0");// setting rejCountLB label to 0 value
            testTB.Text = TBVALUE.ToString("n0");//setting testTB textbox to 0 value
            gpaTB.Text = TBVALUE.ToString("n2");//setting gpaTB textbox to 0 value
        }
    }
}
          
﻿namespace Lab4
{
    partial class Lab4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpaTB = new System.Windows.Forms.TextBox();
            this.testTB = new System.Windows.Forms.TextBox();
            this.testLB = new System.Windows.Forms.Label();
            this.gpaLB = new System.Windows.Forms.Label();
            this.acceptCountLB = new System.Windows.Forms.Label();
            this.rejCountLB = new System.Windows.Forms.Label();
            this.admitLB = new System.Windows.Forms.Label();
            this.rejectLB = new System.Windows.Forms.Label();
            this.admSTATBT = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpaTB
            // 
            this.gpaTB.Location = new System.Drawing.Point(482, 96);
            this.gpaTB.Name = "gpaTB";
            this.gpaTB.Size = new System.Drawing.Size(100, 31);
            this.gpaTB.TabIndex = 2;
            this.gpaTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.gpaTB_KeyPress);
            // 
            // testTB
            // 
            this.testTB.Location = new System.Drawing.Point(482, 38);
            this.testTB.Name = "testTB";
            this.testTB.Size = new System.Drawing.Size(100, 31);
            this.testTB.TabIndex = 1;
            this.testTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.testTB_KeyPress);
            // 
            // testLB
            // 
            this.testLB.AutoSize = true;
            this.testLB.Font = new System.Drawing.Font("Arial", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.testLB.Location = new System.Drawing.Point(22, 38);
            this.testLB.Name = "testLB";
            this.testLB.Size = new System.Drawing.Size(360, 32);
            this.testLB.TabIndex = 0;
            this.testLB.Text = "Enter admissions test score:";
            // 
            // gpaLB
            // 
            this.gpaLB.AutoSize = true;
            this.gpaLB.Font = new System.Drawing.Font("Arial", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpaLB.Location = new System.Drawing.Point(22, 96);
            this.gpaLB.Name = "gpaLB";
            this.gpaLB.Size = new System.Drawing.Size(416, 32);
            this.gpaLB.TabIndex = 0;
            this.gpaLB.Text = "Enter students High School GPA:";
            // 
            // acceptCountLB
            // 
            this.acceptCountLB.AutoSize = true;
            this.acceptCountLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.acceptCountLB.Location = new System.Drawing.Point(133, 302);
            this.acceptCountLB.Name = "acceptCountLB";
            this.acceptCountLB.Size = new System.Drawing.Size(58, 27);
            this.acceptCountLB.TabIndex = 0;
            this.acceptCountLB.Text = "xxxx";
            // 
            // rejCountLB
            // 
            this.rejCountLB.AutoSize = true;
            this.rejCountLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rejCountLB.Location = new System.Drawing.Point(482, 302);
            this.rejCountLB.Name = "rejCountLB";
            this.rejCountLB.Size = new System.Drawing.Size(58, 27);
            this.rejCountLB.TabIndex = 0;
            this.rejCountLB.Text = "xxxx";
            // 
            // admitLB
            // 
            this.admitLB.AutoSize = true;
            this.admitLB.Location = new System.Drawing.Point(87, 254);
            this.admitLB.Name = "admitLB";
            this.admitLB.Size = new System.Drawing.Size(190, 25);
            this.admitLB.TabIndex = 0;
            this.admitLB.Text = "Admitted students:";
            // 
            // rejectLB
            // 
            this.rejectLB.AutoSize = true;
            this.rejectLB.Location = new System.Drawing.Point(419, 254);
            this.rejectLB.Name = "rejectLB";
            this.rejectLB.Size = new System.Drawing.Size(191, 25);
            this.rejectLB.TabIndex = 0;
            this.rejectLB.Text = "Rejected students:";
            // 
            // admSTATBT
            // 
            this.admSTATBT.Location = new System.Drawing.Point(225, 452);
            this.admSTATBT.Name = "admSTATBT";
            this.admSTATBT.Size = new System.Drawing.Size(215, 69);
            this.admSTATBT.TabIndex = 3;
            this.admSTATBT.Text = "Determine admission status";
            this.admSTATBT.UseVisualStyleBackColor = true;
            this.admSTATBT.Click += new System.EventHandler(this.admSTATBT_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(301, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(8, 8);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(8, 39);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(0, 0);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(8, 39);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(0, 0);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // Lab4
            // 
            this.AcceptButton = this.admSTATBT;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 581);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.admSTATBT);
            this.Controls.Add(this.rejectLB);
            this.Controls.Add(this.admitLB);
            this.Controls.Add(this.rejCountLB);
            this.Controls.Add(this.acceptCountLB);
            this.Controls.Add(this.gpaLB);
            this.Controls.Add(this.testLB);
            this.Controls.Add(this.testTB);
            this.Controls.Add(this.gpaTB);
            this.Name = "Lab4";
            this.Text = "Lab4";
            this.Load += new System.EventHandler(this.Lab4_Load);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox gpaTB;
        private System.Windows.Forms.TextBox testTB;
        private System.Windows.Forms.Label testLB;
        private System.Windows.Forms.Label gpaLB;
        private System.Windows.Forms.Label acceptCountLB;
        private System.Windows.Forms.Label rejCountLB;
        private System.Windows.Forms.Label admitLB;
        private System.Windows.Forms.Label rejectLB;
        private System.Windows.Forms.Button admSTATBT;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
    }
}


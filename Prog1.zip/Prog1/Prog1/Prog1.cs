﻿//Grading ID: B2106
//Program 1
//Due Date: September 26, 2017
//Course Section: 75
//This program uses the square footage of a room as well as the number of windows and doors and coats of paint to calculate
//the amount of gallons of paint necessary to accomplish the designated task
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog1
{
    class Prog1
    {
        static void Main(string[] args)
        {
            //setting up constant to represent the 350 divisor needed to calculate the gallons of paint
            const int GALLONS = 350;
            //constant for multiplicative used to calculate subtracted amounts from number of doors
            const int DOORSUB = 20;
            //constant multiplicate used to calculate subtracted amounts from number of windows
            const int WINDOWSUB = 15;

            //variable to represent total wall length
            double totLength;
            //variable represent total wall height
            double heightWall;
            //variable number of doors
            int numDoors;
            //variable number of windows
            int numWindows;
            //variable number of coats
            int numCoats;
            //variable minimum number of gallons required for job
            double minGallons;
            //variable for rounded whole number of gallons of paint required for job
            int gallonsToBuy;


            System.Console.WriteLine("Welcome to the  Handy-Dandy Paint Estimator");//greeting
            Console.Write("\nEnter the total length of all the walls (in feet): ");
            totLength = double.Parse(Console.ReadLine());//assign total length to user input
            Console.Write("Enter the height of the walls (in feet): ");
            heightWall = double.Parse(Console.ReadLine());//assign height of walls to user input
            Console.Write("Enter the number of doors (non-neg int): ");
            numDoors = int.Parse(Console.ReadLine());//assign number of doors to user input
            Console.Write("Enter the number of windows (non-neg int): ");
            numWindows = int.Parse(Console.ReadLine());//assign number of windows to user input
            Console.Write("Enter the number of coats of paint (non-neg int): ");
            numCoats = int.Parse(Console.ReadLine()); //assign number of coats to user input

            //minGallons value being designated via below equation
            minGallons = ((((totLength * heightWall) - (numDoors * DOORSUB)) - (numWindows * WINDOWSUB)) * numCoats) / GALLONS;


            //variable value being declared to round to nearest whole gallon
            gallonsToBuy = (int)Math.Ceiling(minGallons);

            Console.WriteLine($"\nYou should buy {minGallons:N1} gallons of paint");
            Console.WriteLine($"You will need {gallonsToBuy:N0} gallons, though");

        }
    }
}

﻿//Lab 3
//Due 2/12/2017
//CIS 199-02
//by:B2707

//This program displays a form that allows the user to input a meal price
//Once this meal price is input, the user may select a calculate button
//that will display in currency (U.S Dollars) the appropriate tip amount.
// The tip amounts range: small-15% ; medium-18%; large- 20%




using System;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Lab3 : Form
    {
        const decimal SMALL = .15m; //setting small as a constant 15% 
        const decimal MEDIUM = .18m; //setting  medium constant 18%
        const decimal LARGE = .20m; //setting large constat 20%
        private decimal TOTAL = 0m; //setting base total at 0.00
        public Lab3()
        {
            InitializeComponent();
        }
        //setting a key press event that limits user to only numerical digits and decimal places
        private void mealPriceTB_KeyPress(object sender, KeyPressEventArgs e) 
        {  
            //utilizing if statement to limit user to only numerical inputs and decimal inputs       
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            // utilizing if statement that limit user to only one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.')> -1))
            {
                e.Handled = true;
            }
            
        }
        //setting up a click event associated with the "calculate tip" button
        private void tipAmtBT_Click(object sender, EventArgs e)
        {
            //setting up variables
            decimal mealPrice; 

            decimal smTipAmt; 

            decimal medTipAmt;

            decimal lgTipAmt;         


            mealPrice = decimal.Parse(mealPriceTB.Text); //converting decimal to text format for textbox
            
            //retrieving total tip amounts via multiplying percentages with total meal price
            smTipAmt = mealPrice * SMALL; 

            medTipAmt = mealPrice * MEDIUM;

            lgTipAmt = mealPrice * LARGE;

            //Converting text to currency for all labels associated with variables
            smTipAmtLB.Text = smTipAmt.ToString("c"); 

            medTipAmtLB.Text = medTipAmt.ToString("c");

            lgTipAmtLB.Text = lgTipAmt.ToString("c");

        }

        private void Lab3_Load(object sender, EventArgs e)
        {
            //setting load order defaults to currency format
            smTipAmtLB.Text = TOTAL.ToString("c");
            mealPriceTB.Text = TOTAL.ToString("c");
            lgTipAmtLB.Text = TOTAL.ToString("c");
            medTipAmtLB.Text = TOTAL.ToString("c");
            //setting load order defaults to percentage format with no decimal places.
            smTipLB.Text = SMALL.ToString("p0");
            medTipLB.Text = MEDIUM.ToString("p0");
            lgTipLB.Text = LARGE.ToString("p0");
            

        }
    }
}

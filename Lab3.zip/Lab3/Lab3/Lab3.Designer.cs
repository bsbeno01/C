﻿namespace Lab3
{
    partial class Lab3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mealPriceLB = new System.Windows.Forms.Label();
            this.mealPriceTB = new System.Windows.Forms.TextBox();
            this.smTipLB = new System.Windows.Forms.Label();
            this.smTipAmtLB = new System.Windows.Forms.Label();
            this.medTipAmtLB = new System.Windows.Forms.Label();
            this.medTipLB = new System.Windows.Forms.Label();
            this.lgTipLB = new System.Windows.Forms.Label();
            this.lgTipAmtLB = new System.Windows.Forms.Label();
            this.tipAmtBT = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mealPriceLB
            // 
            this.mealPriceLB.AutoSize = true;
            this.mealPriceLB.Font = new System.Drawing.Font("Arial Narrow", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mealPriceLB.Location = new System.Drawing.Point(267, 23);
            this.mealPriceLB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.mealPriceLB.Name = "mealPriceLB";
            this.mealPriceLB.Size = new System.Drawing.Size(202, 31);
            this.mealPriceLB.TabIndex = 0;
            this.mealPriceLB.Text = "Enter price of meal:";
            // 
            // mealPriceTB
            // 
            this.mealPriceTB.Location = new System.Drawing.Point(500, 23);
            this.mealPriceTB.Margin = new System.Windows.Forms.Padding(6);
            this.mealPriceTB.Name = "mealPriceTB";
            this.mealPriceTB.Size = new System.Drawing.Size(196, 31);
            this.mealPriceTB.TabIndex = 1;
            this.mealPriceTB.Text = "0.00";
            this.mealPriceTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mealPriceTB_KeyPress);
            // 
            // smTipLB
            // 
            this.smTipLB.AutoSize = true;
            this.smTipLB.Font = new System.Drawing.Font("Arial Narrow", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smTipLB.Location = new System.Drawing.Point(407, 80);
            this.smTipLB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.smTipLB.Name = "smTipLB";
            this.smTipLB.Size = new System.Drawing.Size(58, 31);
            this.smTipLB.TabIndex = 2;
            this.smTipLB.Text = "15%";
            // 
            // smTipAmtLB
            // 
            this.smTipAmtLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.smTipAmtLB.Location = new System.Drawing.Point(500, 84);
            this.smTipAmtLB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.smTipAmtLB.Name = "smTipAmtLB";
            this.smTipAmtLB.Size = new System.Drawing.Size(198, 42);
            this.smTipAmtLB.TabIndex = 3;
            // 
            // medTipAmtLB
            // 
            this.medTipAmtLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.medTipAmtLB.Location = new System.Drawing.Point(500, 166);
            this.medTipAmtLB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.medTipAmtLB.Name = "medTipAmtLB";
            this.medTipAmtLB.Size = new System.Drawing.Size(198, 42);
            this.medTipAmtLB.TabIndex = 4;
            // 
            // medTipLB
            // 
            this.medTipLB.AutoSize = true;
            this.medTipLB.Font = new System.Drawing.Font("Arial Narrow", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medTipLB.Location = new System.Drawing.Point(407, 166);
            this.medTipLB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.medTipLB.Name = "medTipLB";
            this.medTipLB.Size = new System.Drawing.Size(58, 31);
            this.medTipLB.TabIndex = 5;
            this.medTipLB.Text = "18%";
            // 
            // lgTipLB
            // 
            this.lgTipLB.AutoSize = true;
            this.lgTipLB.Font = new System.Drawing.Font("Arial Narrow", 10.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lgTipLB.Location = new System.Drawing.Point(407, 243);
            this.lgTipLB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lgTipLB.Name = "lgTipLB";
            this.lgTipLB.Size = new System.Drawing.Size(58, 31);
            this.lgTipLB.TabIndex = 6;
            this.lgTipLB.Text = "20%";
            // 
            // lgTipAmtLB
            // 
            this.lgTipAmtLB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lgTipAmtLB.Location = new System.Drawing.Point(498, 245);
            this.lgTipAmtLB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lgTipAmtLB.Name = "lgTipAmtLB";
            this.lgTipAmtLB.Size = new System.Drawing.Size(198, 44);
            this.lgTipAmtLB.TabIndex = 7;
            // 
            // tipAmtBT
            // 
            this.tipAmtBT.Location = new System.Drawing.Point(204, 361);
            this.tipAmtBT.Margin = new System.Windows.Forms.Padding(6);
            this.tipAmtBT.Name = "tipAmtBT";
            this.tipAmtBT.Size = new System.Drawing.Size(324, 100);
            this.tipAmtBT.TabIndex = 8;
            this.tipAmtBT.Text = "Calculate Tip";
            this.tipAmtBT.UseVisualStyleBackColor = true;
            this.tipAmtBT.Click += new System.EventHandler(this.tipAmtBT_Click);
            // 
            // Lab3
            // 
            this.AcceptButton = this.tipAmtBT;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(732, 569);
            this.Controls.Add(this.tipAmtBT);
            this.Controls.Add(this.lgTipAmtLB);
            this.Controls.Add(this.lgTipLB);
            this.Controls.Add(this.medTipLB);
            this.Controls.Add(this.medTipAmtLB);
            this.Controls.Add(this.smTipAmtLB);
            this.Controls.Add(this.smTipLB);
            this.Controls.Add(this.mealPriceTB);
            this.Controls.Add(this.mealPriceLB);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Lab3";
            this.Text = "Lab3";
            this.Load += new System.EventHandler(this.Lab3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label mealPriceLB;
        private System.Windows.Forms.TextBox mealPriceTB;
        private System.Windows.Forms.Label smTipLB;
        private System.Windows.Forms.Label smTipAmtLB;
        private System.Windows.Forms.Label medTipAmtLB;
        private System.Windows.Forms.Label medTipLB;
        private System.Windows.Forms.Label lgTipLB;
        private System.Windows.Forms.Label lgTipAmtLB;
        private System.Windows.Forms.Button tipAmtBT;
    }
}

